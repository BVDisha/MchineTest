from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time

# Set up WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

# Open the website
driver.get("https://demo.dealsdray.com/")

# Maximize window
driver.maximize_window()

# Wait until the username field is present
wait = WebDriverWait(driver, 10)

try:
    username = wait.until(EC.presence_of_element_located((By.ID, "username"))) 
    password = driver.find_element(By.ID, "password")
    
    username.send_keys("prexo.mis@dealsdray.com")
    password.send_keys("prexo.mis@dealsdray.com")

    # Pause the script to keep the window open
    input("Press Enter after verifying that the credentials are filled...")

    driver.find_element(By.ID, "login-button").click() 

    # Wait for the next page to load or use WebDriverWait for specific elements
    time.sleep(5)

except Exception as e:
    print(f"An error occurred: {e}")

finally:

    input("Press Enter to close the browser...")  
