import os
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager

# Function to capture screenshots
def capture_screenshot(driver, resolution, device_name, browser_name, base_url):
    # Set window size
    driver.set_window_size(*resolution)
    driver.get(base_url)

    # Create folder structure
    folder_name = f"{browser_name}/{device_name}/{resolution[0]}x{resolution[1]}"
    os.makedirs(folder_name, exist_ok=True)

    # Save screenshot with timestamp
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    screenshot_path = os.path.join(folder_name, f"screenshot-{timestamp}.png")
    driver.save_screenshot(screenshot_path)
    print(f"Screenshot saved at: {screenshot_path}")

# Function to run tests for a specific browser
def run_tests(browser_name, driver_setup, resolutions, device_name, base_url):
    # Setup WebDriver
    driver = driver_setup()

    # Capture screenshots for all resolutions
    for resolution in resolutions:
        capture_screenshot(driver, resolution, device_name, browser_name, base_url)
    
    driver.quit()

# Function to set up Chrome WebDriver
def setup_chrome():
    options = ChromeOptions()
    options.add_argument("--disable-gpu")
    service = ChromeService(ChromeDriverManager().install())
    return webdriver.Chrome(service=service, options=options)

def setup_firefox():
    options = FirefoxOptions()
    options.binary_location = r"C:\Users\bvdis\AppData\Local\Mozilla Firefox\firefox.exe"  
    service = FirefoxService(GeckoDriverManager().install())
    return webdriver.Firefox(service=service, options=options)


def setup_firefox():
    options = FirefoxOptions()
    service = FirefoxService(GeckoDriverManager().install())
    return webdriver.Firefox(service=service, options=options)

# Main function
if __name__ == "__main__":
    # Base URL to test
    base_url = "https://www.getcalley.com/"

    # Define device resolutions
    desktop_resolutions = [(1920, 1080), (1366, 768), (1536, 864)]
    mobile_resolutions = [(360, 640), (414, 896), (375, 667)]

    # Run tests for Chrome
    run_tests("Chrome", setup_chrome, desktop_resolutions, "Desktop", base_url)
    run_tests("Chrome", setup_chrome, mobile_resolutions, "Mobile", base_url)

    # Run tests for Firefox
    run_tests("Firefox", setup_firefox, desktop_resolutions, "Desktop", base_url)
    run_tests("Firefox", setup_firefox, mobile_resolutions, "Mobile", base_url)